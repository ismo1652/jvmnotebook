
#define VM_JVMTI
#include "bytecodeInterpreter.cpp"


